﻿using System;
using System.Data;

namespace School
{
    class Program
    {
        static void Main(string[] args)
        {
            

            

            
        }
    }
}
